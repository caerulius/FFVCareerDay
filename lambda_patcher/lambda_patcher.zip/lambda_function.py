import ips
import boto3

BUCKET_NAME = 'bigbridgecareerday'
VANILLA_PREFIX = 'vanilla/'
RPGE_PATCH = 'rpge.ips'

def lambda_handler(event, context):
    client = boto3.client('s3')

    response = client.get_object(Bucket=BUCKET_NAME, Key=VANILLA_PREFIX + RPGE_PATCH)
    print(response['Body'].read().decode('utf-8'))
